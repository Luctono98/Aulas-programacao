﻿namespace sistema_login_poo_30._08
{
    partial class FormLogin
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormLogin));
            this.labelLogin = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btEntrar = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.labelSenha = new System.Windows.Forms.Label();
            this.btCadastrar = new System.Windows.Forms.Button();
            this.btEsqueciAsenha = new System.Windows.Forms.Button();
            this.btSair = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // labelLogin
            // 
            this.labelLogin.AutoSize = true;
            this.labelLogin.BackColor = System.Drawing.Color.Transparent;
            this.labelLogin.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelLogin.Location = new System.Drawing.Point(288, 98);
            this.labelLogin.Name = "labelLogin";
            this.labelLogin.Size = new System.Drawing.Size(37, 15);
            this.labelLogin.TabIndex = 1;
            this.labelLogin.Text = "Login";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(412, 165);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(198, 23);
            this.textBox1.TabIndex = 2;
            // 
            // btEntrar
            // 
            this.btEntrar.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btEntrar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btEntrar.Location = new System.Drawing.Point(288, 276);
            this.btEntrar.Name = "btEntrar";
            this.btEntrar.Size = new System.Drawing.Size(94, 45);
            this.btEntrar.TabIndex = 3;
            this.btEntrar.Text = "Entrar";
            this.btEntrar.UseVisualStyleBackColor = false;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(412, 90);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(198, 23);
            this.textBox2.TabIndex = 4;
            // 
            // labelSenha
            // 
            this.labelSenha.AutoSize = true;
            this.labelSenha.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.labelSenha.Location = new System.Drawing.Point(288, 173);
            this.labelSenha.Name = "labelSenha";
            this.labelSenha.Size = new System.Drawing.Size(41, 15);
            this.labelSenha.TabIndex = 5;
            this.labelSenha.Text = "Senha";
            // 
            // btCadastrar
            // 
            this.btCadastrar.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btCadastrar.ForeColor = System.Drawing.Color.Transparent;
            this.btCadastrar.Location = new System.Drawing.Point(443, 276);
            this.btCadastrar.Name = "btCadastrar";
            this.btCadastrar.Size = new System.Drawing.Size(88, 45);
            this.btCadastrar.TabIndex = 6;
            this.btCadastrar.Text = "Cadastrar";
            this.btCadastrar.UseVisualStyleBackColor = false;
            // 
            // btEsqueciAsenha
            // 
            this.btEsqueciAsenha.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btEsqueciAsenha.ForeColor = System.Drawing.Color.Transparent;
            this.btEsqueciAsenha.Location = new System.Drawing.Point(508, 343);
            this.btEsqueciAsenha.Name = "btEsqueciAsenha";
            this.btEsqueciAsenha.Size = new System.Drawing.Size(125, 50);
            this.btEsqueciAsenha.TabIndex = 7;
            this.btEsqueciAsenha.Text = "Esqueci a senha";
            this.btEsqueciAsenha.UseVisualStyleBackColor = false;
            // 
            // btSair
            // 
            this.btSair.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btSair.ForeColor = System.Drawing.Color.Transparent;
            this.btSair.Location = new System.Drawing.Point(604, 276);
            this.btSair.Name = "btSair";
            this.btSair.Size = new System.Drawing.Size(97, 45);
            this.btSair.TabIndex = 8;
            this.btSair.Text = "Sair";
            this.btSair.UseVisualStyleBackColor = false;
            this.btSair.Click += new System.EventHandler(this.btSair_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 99);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(213, 222);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // FormLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btSair);
            this.Controls.Add(this.btEsqueciAsenha);
            this.Controls.Add(this.btCadastrar);
            this.Controls.Add(this.labelSenha);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btEntrar);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.labelLogin);
            this.Name = "FormLogin";
            this.Text = "Tela de login";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Label labelLogin;
        private TextBox textBox1;
        private Button btEntrar;
        private TextBox textBox2;
        private Label labelSenha;
        private Button btCadastrar;
        private Button btEsqueciAsenha;
        private Button btSair;
        private PictureBox pictureBox1;
    }
}